Nejprve je treba nainstalovat sphinx - pouzita verze 3.4.1
postup instalace
https://drib.tech/programming/install-sphinx-3-fedora-30-thirty
